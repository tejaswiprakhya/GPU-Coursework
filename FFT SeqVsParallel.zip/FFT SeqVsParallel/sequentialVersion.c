//**************************************************************
// Assignment #4
// Name: Tejaswi Prakhya, and NandaKishore Reddy Thineti
// FFT sequential code: Date of Submission (04/10/2017)
//Foldername : Illuminati_HW_4
//***************************************************************
//We are implementing the Cooley�Tukey FFT algorithm. Initially calculates the even and odd part in the given processed samples. The even and odd parts have individual real and imaginary
//parts. Later we summup the real and imaginary parts.
//Please change the processed samples above accordingly.
//**************************************************************** 

#include<stdio.h>
#include<stdlib.h>										
#include<math.h>
#include<time.h>
#include"timer.h"
								
#define PI 3.14159


//*******************************************************************
//Main function declaration
//********************************************************************
void main()											//main function starts
{
	int n, m, k, r,i;
	double timeCompStart, timeCompEnd, timeComp;
	printf("TOTAL PROCESSED SAMPLES:");							//standard input from console that asks user to enter sample size
	scanf("%d", &n);
	float size = n*sizeof(float);
	float xr[8] = { 3.6,2.9,5.6,4.8,3.3,5.9,5.0,4.3 };					//real values as given stored in array
	float xi[8] = { 2.6,6.3,4.0,9.1,0.4,4.8,2.6,4.1 };					//imaginary values as given stored in array
	float *rev, *rod, *iev, *iod, *t, *e, *t1, *e1, *xr1, *xi1, *xreal, *ximg;
	rev = (float*)malloc(size);
	rod = (float*)malloc(size);
	iev = (float*)malloc(size);	
	iod = (float*)malloc(size);
	t = (float*)malloc(size);
	e = (float*)malloc(size);
	t1 = (float*)malloc(size);
	e1 = (float*)malloc(size);
	xr1 = (float*)malloc(size);
	xi1 = (float*)malloc(size);
	xreal = (float*)malloc(size);
	ximg = (float*)malloc(size);

		
	
	float sumr, sumi, coeff;
	float a[100], b[100];
	
	

	printf("==================\n");

	for (i = 0; i < 8; i++)									//copying values into xr and xi arrays
	{
		xr1[i] = xr[i];
		xi1[i] = xi[i];
	}
	for (i = 8; i < n; i++)									//rest of the values in xr and xi arrays are set to 0's
	{
		xr1[i] = xi1[i] = 0;
	}
	GET_TIME(timeCompStart);

	for(k=0;k<n;k++){
		for (m = 0; m <n ; m=m+2)							//Calculating for even components
			{
			t[m] = cos((2 * PI *  m*k) / n);
			//printf("%f\n", t[m]);
			e[m]= sin((2 * PI * m*k) / n);
			rev[m] = (xr1[m])*t[m]+ (xi1[m])*e[m];
			iev[m] = (xi1[m])*t[m] - (xr1[m])*e[m];
			}
		for (m = 1; m < n ; m=m+1)							//Calculating for odd components
		{
			t1[m] = cos((2 * PI * m*k) / n);
			e1[m] = sin((2 * PI * m*k) / n);
			rev[m] = (xr1[ m])*t1[m]+ (xi1[m])*e1[m];
			iev[m] = (xi1[m])*t1[m]- (xr1[m])*e1[m];
		}

	sumr =0;
	sumi=0;
	for(i=0;i<n;i++)
		{
		sumr=sumr+rev[i];
		sumi=sumi+iev[i];
		}
	xreal[k]=sumr;
	ximg[k]=sumi;
	}

	GET_TIME(timeCompEnd);
	timeComp = timeCompEnd - timeCompStart;

	for(k=0;k<=10;k++)
		{
		//printf("%f   %f\n", xreal[k], ximg[k]);
		printf("XR[%d]:%0.1f  XI[%d]:%f\n", k,xreal[k],k, ximg[k]);
		printf("=================\n");
		}

	printf("\nComputation Time : %f seconds\n",timeComp);

	
}												//main function ends